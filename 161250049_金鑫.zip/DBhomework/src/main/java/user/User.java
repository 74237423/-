package user;
import java.util.ArrayList;
import phone_package.Phone_package;

public class User {

    String user_name;
    String phone_number;
    public User(String name, String number){
        user_name = name;
        phone_number = number;
    }
}

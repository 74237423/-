package Main;
import phone_package.Phone_package;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

public class CountBill {

    Database d = new Database();

    /*date格式yyyy-MM
     * 计算某月账单
     * */
    public void countMonthBill(String phone,String date){
        int num1,num2,num3,num4,num11,num22,num33,num44;
        if(leftfree_call(phone,date)<0) {
            num1 = 0;
            num11 = -leftfree_call(phone,date);
        }
        else {
            num1 = leftfree_call(phone,date);
            num11 = 0;
        }
        if(leftfree_mesage(phone,date)<0){
            num2 = 0;
            num22 = -leftfree_mesage(phone,date);
        }
        else {
            num2 = leftfree_mesage(phone,date);
            num22 = 0;
        }
        if(leftfree_netLocal(phone,date)<0){
            num3 = 0;
            num33 = -leftfree_netLocal(phone,date);
        }
        else {
            num3 = leftfree_netLocal(phone,date);
            num33 = 0;
        }
        if(leftfree_netNation(phone,date)<0){
            num4 = 0;
            num44 = -leftfree_netNation(phone,date);
        }
        else {
            num4 = leftfree_netNation(phone,date);
            num44 =0;
        }
        //当本地流量用完而全国流量还有剩余的时候
        if(num4>0&&num33>0&&num4>num33){
            num4 = num4 - num33;
            num33 = 0;
        }
        if(num4>0&&num33>0&&num4<num33){
            num4 = 0;
            num33 = num33 - num4;
        }


        String userName = d.getUserName(phone);
        System.out.println("开始计算账单");
        System.out.println(date+"账单  姓名:"+userName+"  电话号码："+phone);
        long startTime = System.currentTimeMillis();
        System.out.println("套餐通话剩余："+num1+"分钟 短信剩余："+num2+"条  本地流量剩余："+num3+"M  全国流量剩余："+num4+"M");
        System.out.println("超出套餐通话："+num11+"分钟  超出套餐短信"+num22+"条  超出套餐本地流量："+num33+"M  超出套餐全国流量："+num44+"M");
        double extertotal = 0.5*num11+0.1*num22+2*num33+5*num44;
        double total = extertotal + totalBaseCost(phone, date);
        System.out.println("套餐基础费用："+totalBaseCost(phone, date)+"元  超出套餐费用："+extertotal+"元  总费用："+total+"元");
        System.out.println("打印月账单结束,用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
        System.out.println();
    }


    public double countMonthBill1(String phone,String date){
        int num1,num2,num3,num4,num11,num22,num33,num44;
        if(leftfree_call(phone,date)<0) {
            num1 = 0;
            num11 = -leftfree_call(phone,date);
        }
        else {
            num1 = leftfree_call(phone,date);
            num11 = 0;
        }
        if(leftfree_mesage(phone,date)<0){
            num2 = 0;
            num22 = -leftfree_mesage(phone,date);
        }
        else {
            num2 = leftfree_mesage(phone,date);
            num22 = 0;
        }
        if(leftfree_netLocal(phone,date)<0){
            num3 = 0;
            num33 = -leftfree_netLocal(phone,date);
        }
        else {
            num3 = leftfree_netLocal(phone,date);
            num33 = 0;
        }
        if(leftfree_netNation(phone,date)<0){
            num4 = 0;
            num44 = -leftfree_netNation(phone,date);
        }
        else {
            num4 = leftfree_netNation(phone,date);
            num44 =0;
        }
        //当本地流量用完而全国流量还有剩余的时候
        if(num4>0&&num33>0&&num4>num33){
            num4 = num4 - num33;
            num33 = 0;
        }
        if(num4>0&&num33>0&&num4<num33){
            num4 = 0;
            num33 = num33 - num4;
        }


        double extertotal = 0.5*num11+0.1*num22+2*num33+5*num44;
        return extertotal + totalBaseCost(phone, date);

    }

    //计算某月套餐基本费用
    public double totalBaseCost(String phone,String date){
        double m = 0;
        ArrayList<Phone_package> list = d.getMonthPackage(phone,date);
        for (int i = 0; i < list.size(); i++){
            m += list.get(i).base_bill;
        }
        return m;
    }



    /*date格式yyyy-MM
    * 某月所有套餐的免费短信
    * */
    public int free_message(String phone,String date){
        int m = 0;
        ArrayList<Phone_package> list = d.getMonthPackage(phone,date);
        for (int i = 0; i < list.size(); i++){
            m += list.get(i).freeMessage;
        }
        return m;
    }
    /*date格式yyyy-MM
     * 某月所有套餐的免费通话
     * */
    public int free_call(String phone,String date){
        int c = 0;
        ArrayList<Phone_package> list = d.getMonthPackage(phone,date);
        for (int i = 0; i < list.size(); i++){
            c += list.get(i).freeCall;
        }
        return c;
    }
    /*date格式yyyy-MM
     * 某月所有套餐的免费本地流量
     * */
    public int free_netLocal(String phone,String date){
        int m = 0;
        ArrayList<Phone_package> list = d.getMonthPackage(phone,date);
        for (int i = 0; i < list.size(); i++){
            m += list.get(i).freeLocalNet;
        }
        return m;
    }
    /*date格式yyyy-MM
     * 某月所有套餐的免费全国流量
     * */
    public int free_netNation(String phone,String date){
        int m = 0;
        ArrayList<Phone_package> list = d.getMonthPackage(phone,date);
        for (int i = 0; i < list.size(); i++){
            m += list.get(i).freeNationNet;
        }
        return m;
    }



    /*date格式yyyy-MM
     * 某月所有套餐的剩余免费全国流量
     * */
    public int leftfree_netNation(String phone,String date){
        return free_netNation(phone,date)-d.nationNetUsed(phone,date);
    }

    /*date格式yyyy-MM
     * 某月所有套餐的剩余免费本地流量
     * */
    public int leftfree_netLocal(String phone,String date){
        return free_netLocal(phone,date)-d.localNetUsed(phone,date);

    }

    /*date格式yyyy-MM
     * 某月所有套餐的剩余免费通话
     * */
    public int leftfree_call(String phone,String date){
        return free_call(phone,date)-d.callTimeUsed(phone,date);
    }

    /*date格式yyyy-MM
     * 某月所有套餐的剩余免费本地流量
     * */
    public int leftfree_mesage(String phone,String date){

        return free_message(phone,date)-d.messageUsed(phone,date);
    }
}

package Main;

import phone_package.Phone_package;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class Database {
    //获取与数据库的连接
    private static Connection getConn() {
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/db";
        String username = "root";
        String password = "161250049";
        Connection conn = null;
        try {
            Class.forName(driver); //classLoader,加载对应驱动
            conn = (Connection) DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    //查找并打印某用户所有套餐
    public void getAllPackage(String phone){
        Connection connection = getConn();
        long startTime = System.currentTimeMillis();
        try{
            String sql = "SELECT * from db.deal where phone = '"+phone+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            //结果集
            ResultSet rs = prst.executeQuery();
            String name = getUserName(phone);
            System.out.println("开始查询套餐");
            System.out.println("姓名："+name+"  电话号码："+phone);
            System.out.println("-----------------------------------------");
            while (rs.next()) {
                String pname = getPname(rs.getInt("pid"));
                System.out.println("套餐名称："+pname+"  生效时间："+rs.getString("starttime")+"  结束时间："+rs.getString("endtime"));
            }
            System.out.println("查询套餐结束,用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
            System.out.println();
            rs.close();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("查找失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }


    }

    //查找某用户某月所有套餐 date:yyyy-MM
    public ArrayList<Phone_package> getMonthPackage(String phone,String date){
        Connection connection = getConn();
        String year = date.substring(0,4);
        String month = date.substring(5,7);
        ArrayList<Phone_package> phone_packages = new ArrayList<Phone_package>();
        try{
            //mysql查询语句
            String sql = "SELECT pid FROM db.deal WHERE phone = '"+phone+"'and  YEAR(starttime) <= '"
                    +year+"'and YEAR(endtime) >= '"+year+"' and MONTH(starttime) <= '"+month+"' and MONTH(endtime) >= '"+month+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            //结果集
            ResultSet rs = prst.executeQuery();
            while (rs.next()) {
                phone_packages.add(new Phone_package(rs.getInt("pid")));
            }
            rs.close();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return phone_packages;
    }

    //查找某用户某月通话时间
    public int callTimeUsed(String phone,String date){
        int time = 0;
        Connection connection = getConn();
        String year = date.substring(0,4);
        String month = date.substring(5,7);
        try{
            String sql = "SELECT * from db.usedrecord where phone = '"+phone+"' and type = '通话' and YEAR(time) = '"+year+"' and MONTH(time) = '"+month+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            //结果集
            ResultSet rs = prst.executeQuery();
            while (rs.next()){
                time += rs.getInt("num");
            }
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("查找通话时间失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return time;
    }

    //查找某用户某月短信条数
    public int messageUsed(String phone,String date){
        int time = 0;
        Connection connection = getConn();
        String year = date.substring(0,4);
        String month = date.substring(5,7);
        try{
            String sql = "SELECT * from db.usedrecord where phone = '"+phone+"' and type = '短信' and YEAR(time) = '"+year+"' and MONTH(time) = '"+month+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            //结果集
            ResultSet rs = prst.executeQuery();
            while (rs.next()){
                time += rs.getInt("num");
            }
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("查找通话时间失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return time;
    }

    //查找某用户某月本地流量使用情况
    public int localNetUsed(String phone,String date){
        int time = 0;
        Connection connection = getConn();
        String year = date.substring(0,4);
        String month = date.substring(5,7);
        try{
            String sql = "SELECT * from db.usedrecord where phone = '"+phone+"' and type = '本地流量' and YEAR(time) = '"+year+"' and MONTH(time) = '"+month+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            //结果集
            ResultSet rs = prst.executeQuery();
            while (rs.next()){
                time += rs.getInt("num");
            }
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("查找通话时间失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return time;
    }

    //查找某用户某月全国流量使用情况
    public int nationNetUsed(String phone,String date){
        int time = 0;
        Connection connection = getConn();
        String year = date.substring(0,4);
        String month = date.substring(5,7);
        try{
            String sql = "SELECT * from db.usedrecord where phone = '"+phone+"' and type = '全国流量' and YEAR(time) = '"+year+"' and MONTH(time) = '"+month+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            //结果集
            ResultSet rs = prst.executeQuery();
            while (rs.next()){
                time += rs.getInt("num");
            }
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("查找通话时间失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return time;
    }

    //插入消费记录
    public void insertRecord(String phone,String type,int num){
        Connection connection = getConn();
        Date date = new Date();
        // 获取当前系统时间和日期并格式化:
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:MM:ss");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        try {
            String sql = "insert into db.usedrecord (time,type,num,phone) values(?,?,?,?)";
            PreparedStatement prst = connection.prepareStatement(sql);
            prst.setString(1,dateTime);
            prst.setString(2,type);
            prst.setInt(3,num);
            prst.setString(4,phone);
            prst.executeUpdate();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("插入消费记录失败");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }



    }



    /* 用户当月增加某套餐
    * phone 电话号码
    * numOfMonth  套餐结束日期 格式yyyy-MM-dd
    * pname 套餐名称
    * */
    public void addThisMonth(String phone, String endDate, String pname){
        Connection connection = getConn();
        Date date = new Date();
        // 获取当前系统时间和日期并格式化:
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        java.sql.Date sDate = null;
        try {
            java.util.Date date3 = sdf2.parse(dateTime);
            sDate = new java.sql.Date(date3.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        java.sql.Date sDate2 = null;
        try {
            java.util.Date date3 = sdf2.parse(endDate);
            sDate2 = new java.sql.Date(date3.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int pid = getpid(pname);
        try{
            long startTime = System.currentTimeMillis();
            String sql = "INSERT INTO db.deal(phone,pid,starttime,endtime)VALUES (?,?,?,?)";
            PreparedStatement prst = connection.prepareStatement(sql);
            prst.setString(1,phone);
            prst.setInt(2,pid);
            prst.setDate(3,sDate);
            prst.setDate(4,sDate2);
            prst.executeUpdate();
            System.out.println(phone+"当月增加"+pname+"直到"+endDate+"结束");
            System.out.println("该操作用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
            System.out.println();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("添加套餐失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    //用户次月增加某套餐
    public void addNextMonth(String phone, String endDate, String pname){
        Date date = new Date();
        // 获取当前系统时间和日期并格式化:
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        String nextMonthDate = getFirstDayOfNextMonth(dateTime,"yyyy-MM-dd");
        Connection connection = getConn();
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        java.sql.Date sDate = null;
        try {
            java.util.Date date3 = sdf2.parse(nextMonthDate);
            sDate = new java.sql.Date(date3.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        java.sql.Date sDate2 = null;
        try {
            java.util.Date date3 = sdf2.parse(endDate);
            sDate2 = new java.sql.Date(date3.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int pid = getpid(pname);
        try{
            long startTime = System.currentTimeMillis();
            String sql = "INSERT INTO db.deal(phone,pid,starttime,endtime)VALUES (?,?,?,?)";
            PreparedStatement prst = connection.prepareStatement(sql);
            prst.setString(1,phone);
            prst.setInt(2,pid);
            prst.setDate(3,sDate);
            prst.setDate(4,sDate2);
            prst.executeUpdate();
            System.out.println(phone+"次月增加"+pname+"直到"+endDate+"结束");
            System.out.println("该操作用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
            System.out.println();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("添加套餐失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    //用户当月退订某套餐
    public void deleteThisMonth(String phone, String pname){
        Connection connection = getConn();
        Date date = new Date();
        // 获取当前系统时间和日期并格式化:
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        int pid = getpid(pname);
        try{
            long startTime = System.currentTimeMillis();
            String sql = "UPDATE db.deal set endtime = '"+dateTime+"' WHERE phone = '"+phone+"' and pid = '"+pid+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            prst.executeUpdate();
            System.out.println(phone+"当月退订"+pname);
            System.out.println("该操作用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
            System.out.println();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("退订套餐失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    //用户次月退订某套餐
    public void deleteNextMonth(String phone, String pname){
        Connection connection = getConn();
        String dateTime = getMaxMonthDate();
        int pid = getpid(pname);

        try{
            long startTime = System.currentTimeMillis();
            String sql = "UPDATE db.deal set endtime = '"+dateTime+"' WHERE phone = '"+phone+"' and pid = '"+pid+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            prst.executeUpdate();
            System.out.println(phone+"次月退订"+pname);
            System.out.println("该操作用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
            System.out.println();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("退订套餐失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    //根据电话号码查找用户姓名
    public String getUserName(String phone){
        Connection connection = getConn();
        String name="";
        try {
            String sql = "select name from db.user where phone =  '"+phone+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            ResultSet rs = prst.executeQuery();
            while (rs.next()){
                name = rs.getString("name");
                return name;
            }
            rs.close();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("查找失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
    //根据套餐名称查找套餐id
    public int getpid(String pname){
        Connection connection = getConn();
        int id=0;
        try {
            String sql = "select pid from db.package where pname =  '"+pname+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            ResultSet rs = prst.executeQuery();
            while (rs.next()){
                id = rs.getInt("pid");
                return id;
            }
            rs.close();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("查找失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return id;
    }
    //根据id查找套餐名称
    public String getPname(int pid){
        Connection connection = getConn();
        String name="";
        try {
            String sql = "select pname from db.package where pid =  '"+pid+"'";
            PreparedStatement prst = connection.prepareStatement(sql);
            ResultSet rs = prst.executeQuery();
            while (rs.next()){
                name = rs.getString("pname");
                return name;
            }
            rs.close();
            prst.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("查找失败！！！");
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    /**

      * 获取指定日期下个月的第一天
     * @param dateStr
     * @param format
     * @return
     */
    public static String getFirstDayOfNextMonth(String dateStr,String format){
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        try {
            Date date = sdf.parse(dateStr);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.set(Calendar.DAY_OF_MONTH,1);
            calendar.add(Calendar.MONTH, 1);
            return sdf.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
    /**
     * 获取当前月份最后一天
     */
    public static String getMaxMonthDate() {
        SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        // calendar.add(Calendar.MONTH, -1);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return dft.format(calendar.getTime());
    }

}

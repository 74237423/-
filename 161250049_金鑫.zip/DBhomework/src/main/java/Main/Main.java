package Main;
import phone_package.Phone_package;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
//套餐目前只设有：短信套餐，话费套餐，本地流量套餐，全国流量套餐
    public static void main(String[] args) {
        Database d = new Database();
        CountBill b = new CountBill();
        d.getAllPackage("15996065160");//对该号码进行套餐查询
        d.deleteNextMonth("15996065160","话费套餐");//次月退订话费套餐
        d.getAllPackage("15996065160");//对该号码进行套餐查询
        d.deleteThisMonth("15996065160","话费套餐");//当月退订话费套餐
        d.getAllPackage("15996065160");//对该号码进行套餐查询
        d.addThisMonth("15996065160","2019-10-31","话费套餐");//当月订购话费套餐到2019-10-31结束
        d.getAllPackage("15996065160");//对该号码进行套餐查询
        d.addNextMonth("15996065160","2018-12-31","短信套餐");//次月订购短信套餐到2018-12-31结束
        d.getAllPackage("15996065160");//对该号码进行套餐查询


        b.countMonthBill("15996065160","2018-10");//查询2018-10月账单
        call("15996065160",10);//模拟现在打电话10分钟，并生成此次资费
        surf("15996065160",90);//模拟现在本地上网90M，并生成此次资费
        surf2("15996065160",2039);//模拟现在外地上网2039M，并生成此次资费
        b.countMonthBill("15996065160","2018-10");//查询2018-10月账单

        d.deleteThisMonth("15996065160","短信套餐");//当月退订短信套餐，便于循环运行main方法

    }
    /*某个人现在打电话资费生成方法
    * lasttime是通话持续时间
    * */
    public static void call(String phone,int lasttime){
        Database d = new Database();
        CountBill b = new CountBill();
        Date date = new Date();
        // 获取当前系统时间和日期并格式化:
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        double costBefore = b.countMonthBill1(phone,dateTime);
        System.out.println(phone+"现在开始打了"+lasttime+"分钟的电话");
        long startTime = System.currentTimeMillis();
        d.insertRecord(phone,"通话",lasttime);
        double costAfter = b.countMonthBill1(phone,dateTime);
        double cost = costAfter - costBefore;
        System.out.println("该通话额外花费了"+cost+"元");
        System.out.println("记录该消费记录到数据库,用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
    }

    /*某个人现在本地上网资费生成方法
     * num是上网所用流量
     * */
    public static void surf(String phone,int num){
        Database d = new Database();
        CountBill b = new CountBill();
        Date date = new Date();
        // 获取当前系统时间和日期并格式化:
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        double costBefore = b.countMonthBill1(phone,dateTime);
        System.out.println(phone+"现在开始在本地用了"+num+"M的流量");
        long startTime = System.currentTimeMillis();
        d.insertRecord(phone,"本地流量",num);
        double costAfter = b.countMonthBill1(phone,dateTime);
        double cost = costAfter - costBefore;
        System.out.println("该上网额外花费了"+cost+"元");
        System.out.println("记录该消费记录到数据库和计算此次消费共用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
        System.out.println();
    }

    /*某个人现在外地上网资费生成方法
     * num是上网所用流量
     * */
    public static void surf2(String phone,int num){
        Database d = new Database();
        CountBill b = new CountBill();
        Date date = new Date();
        // 获取当前系统时间和日期并格式化:
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        double costBefore = b.countMonthBill1(phone,dateTime);
        System.out.println(phone+"现在开始在外地用了"+num+"M的流量");
        long startTime = System.currentTimeMillis();
        d.insertRecord(phone,"全国流量",num);
        double costAfter = b.countMonthBill1(phone,dateTime);
        double cost = costAfter - costBefore;
        System.out.println("该上网额外花费了"+cost+"元");
        System.out.println("记录该消费记录到数据库和计算此次消费共用时: " + (System.currentTimeMillis() - startTime) + " 毫秒");
        System.out.println();
    }

}

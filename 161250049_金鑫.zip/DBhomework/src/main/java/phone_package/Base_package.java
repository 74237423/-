package phone_package;

public class Base_package {
    public static final double call_cost = 0.5; //通话费用：0.5元/分钟（仅拨打收费，接听免费）
    public static final double message_cost = 0.1; //短信费用：0.1元/条
    public static final double net_cost_local = 2; //本地流量费用（仅考虑4G流量）：2元/M
    public static final double net_cost_nation = 5; //国内流量费用（仅考虑4G流量）：5元/M
}

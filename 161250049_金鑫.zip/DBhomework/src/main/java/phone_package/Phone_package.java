package phone_package;
/* 基准资费  */
public class Phone_package {
    public int pid;

    public double base_bill;
    public int freeCall;
    public int freeMessage;
    public int freeLocalNet;
    public int freeNationNet;
    public Phone_package(int id){
        pid = id;
        if(id == 1){
            base_bill = 20;
            freeCall = 100;
            freeMessage = 0;
            freeLocalNet = 0;
            freeNationNet = 0;
        }
        else if(id == 2){
            base_bill = 10;
            freeCall = 0;
            freeMessage = 200;
            freeLocalNet = 0;
            freeNationNet = 0;
        }else if(id == 3){
            base_bill = 20;
            freeCall = 0;
            freeMessage = 0;
            freeLocalNet = 2048;
            freeNationNet = 0;
        }else if(id == 4){
            base_bill = 30;
            freeCall = 0;
            freeMessage = 0;
            freeLocalNet = 0;
            freeNationNet = 2048;
        }
    }
}

